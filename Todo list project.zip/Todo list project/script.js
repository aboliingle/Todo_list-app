/***Fetch HTML Elements from DOM and store them in a Variable */
var listElement = document.querySelector('#list');
var inputElement = document.querySelector('.todo-input');

/***On window load
 1. Call a function to Get Values from Local Storage when 
 2. Call a function to add event listeners on the list items
 ****/
window.onload = function(){
    getValues();
    addClickEvents();
}

/***addItem(): Adds new list items to the DOM when "add" button on the HTML Page is clicked ***/
function addItem()
{
  //item is added only when input box value is not empty
  if(inputElement.value != '')
  {
    listElement.innerHTML += '<li>' + inputElement.value + '</li>';
    //Call store() function to save the new list item in localStorage
    store();
    //set the input box to blank after adding the value
    inputElement.value = "";
  }
  //Call a function to add event listeners on the new list items
  addClickEvents();
}
   
/*****store(): saves the list items in localStorage*****/
function store() {
  window.localStorage.setItem('myitems',listElement.innerHTML );
}
  
/***getValues(): retrieves the values from localStorage and sets it to the UL DOM element****/
function getValues()
 {
  var storedValues = window.localStorage.getItem('myitems');
  //Display the values only if local storge is not empty
    if(storedValues != '')
    {
      listElement.innerHTML = storedValues;
    }
 }

 /*******Additional*******/

/***addClickEvenets() : add event listeners on the list items for click and double click*****/
function addClickEvents(){
  document.querySelectorAll('li').forEach ( item => {
  item.addEventListener('click', strikeTheItem);
  item.addEventListener('dblclick', deleteTheItem);
})
}

function strikeTheItem(){
  /****Click :adds .strike class to the list item if not added already, if it is added it will remove it****/
   if(this.classList.contains('strike')){
      this.classList.remove("strike");
  }
  else{
    this.classList.add("strike");
  }
  
}

function deleteTheItem(){
  /**Double click : removes stroked elements only**/
  if(this.classList.contains('strike'))
  {
      this.remove();;
  }
}


  